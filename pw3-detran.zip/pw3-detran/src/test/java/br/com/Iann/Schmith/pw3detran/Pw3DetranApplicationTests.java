package br.com.Iann.Schmith.pw3detran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw3DetranApplicationTests {

	@Test
	void contextLoads() {
	}

}
